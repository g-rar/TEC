package com.example.lopez.picz.classes;

import android.graphics.Bitmap;

public interface PiczImage {
    Bitmap getBitMap();
    void setBitmap(Bitmap bm);
}