package com.example.lopez.picz.room;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.lopez.picz.R;

public class PiczSingleStoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_picz_single_story);


    }
}
